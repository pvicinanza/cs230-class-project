#!/usr/bin/env python3

import numpy as np
import pandas as pd
import os
import csv  # Used for glove2dict
from mittens import GloVe, Mittens
import scipy.sparse as sp
import tensorflow as tf
from multiprocessing import Pool  # To parallelize

pretrained = 'embeddings/wikipedia2014_gigaword_embeddings/glove.6B.100d.txt'
subfolder = 'even_split_min20/'   # Subfolder to save embeddings to

# Properties of the embeddings
num_epoch = 250
xmax = 100
mittens = 0.1
num_processes = 8

print("Embedding subfolder  {}".format(subfolder))
print("Number of epochs: {}".format(num_epoch))
print("Xmax: {}".format(xmax))
print("Mittens value: {}".format(mittens))
print("Number of cores: {}".format(num_processes))

# Load the pretrained vector
def glove2dict(glove_filename):
    '''
        Reads a glove file into a dictionary
        Taken from: https://github.com/roamanalytics/mittens
    '''
    with open(glove_filename, encoding="utf8") as f:
        reader = csv.reader(f, delimiter=' ', quoting=csv.QUOTE_NONE)
        embed = {line[0]: np.array(list(map(float, line[1:])))
                for line in reader}
    return embed



def train_mittens(coo_matrix, pretrained, filename=None, max_iter=200,
                  xmax=100, learning_rate=0.05, tol=1e-4,
                  display_progress=10,
                  mittens=0.1, encoding='utf-8'):
    '''
    Parameters:
        See https://github.com/roamanalytics/mittens/blob/master/mittens/doc.py for 
            full description of the Mittens model parameters
        coo_matrix - n x n weighted cooccurance matrix
        pretrained - pretrained embedding (from glove2dict)
        filename - Filename to save the embeddeding (if provided)
        max_iter - number of iterations to run
        xmax - Word pairs with frequency greater than this are given weight 1.0.
        learning_rate - alpha for Adam Optimization
        tol - Stopping criterion for the loss
        display_progress - Frequency with which to update the progress bar
        mittens - Relative weight assigned to remaining close to the original
            embeddings. Setting to 0 means that representations are
            initialized with the original embeddings but there is no
            penalty for deviating from them. Large positive values will
            heavily penalize any deviation, so the statistics of the new
            co-occurrence matrix will be increasingly ignored. A value of
            1 is 'balanced': equal weight is given to the GloVe objective
            on the new co-occurrence matrix and to remaining close to the
            original embeddings. 0.1 (the default) is recommended.

    Returns a trained mittens model


    '''
    vocab = coo_matrix.index.values.tolist()
    dim = len(list(pretrained.values())[0])

    # Train mittens
    mittens_model = Mittens(n=dim, max_iter=max_iter, xmax=xmax,
                            learning_rate=learning_rate, tol=tol,
                            display_progress=display_progress,
                            mittens=mittens)
    model = mittens_model.fit(
        coo_matrix,
        vocab=vocab,
        initial_embedding_dict=pretrained)

    # If the user provides a filename 
    if filename:
        save_mittens(model, vocab, filename, encoding=encoding)

    return model



def save_mittens(model, vocab, filename, encoding='utf-8'):
    '''
    Saves Mittens model in a format which can
        be read by gensim
    Parameters:
        Model - Trained Mittens object
        vocab - List of vocab in same order as model fit
        filename - Filename to save to
        encoding - File encoding
    '''

    with open(filename, 'w', encoding=encoding) as outfile:
        # Write file header
        outfile.write("{} {}\n".format(model.shape[0], model.shape[1]))

        # Write word - vector
        for word, index in zip(vocab, range(len(model))):
            outfile.write(word + ' ' + ' '.join(str(x) for x in model[index]) + '\n')


def full_mittens_parallel(t):
    '''
    Implements the full mittens pipeline
    Parameters:
        t - a tuple containing:
        model_name - file path for model name
        model_name_wv - file path to save the model
        pretrained_dict - dictionary of pretrained glove embeddings
        max_iter - number of iterations for training mittens
        xmax - maximum value in cooccurance matrix
        mittens - mittens parameter
    '''

    model_name, model_name_wv, pretrained_dict, max_iter, xmax, mittens = t

    # Reads in the cooccurance matrix
    model = pd.read_csv(model_name + '.csv', sep='|', index_col=0, 
                        keep_default_na=False, na_values=[''])

    # Train and save the model
    train_mittens(model, pretrained_dict, model_name_wv + '.txt',
                  max_iter=max_iter, xmax=xmax, mittens=mittens)


# Read in pretrained embedding
embed = glove2dict(pretrained)



# Zip up the parameters to pass to parallelizier
params = []
files = os.listdir('embeddings/cooc/{}'.format(subfolder))
files = [os.path.splitext(x)[0] for x in files]
for file_name in files:
    print("Training embedding for year: {}".format(file_name))
    model_name = "embeddings/cooc/{}{}".format(subfolder, file_name)
    model_name_wv = "embeddings/wv/{}{}_wv".format(subfolder, file_name)
    
    params.append((model_name, model_name_wv, embed, num_epoch, 
                   xmax, mittens))



# Parallelize and run
if __name__ == "__main__":
    print("Mittens Parallelization")
    p = Pool(processes=num_processes)
    p.map(full_mittens_parallel, params)