'''
Author: Paul Vicinanza
Date: 11/29/2018
Purpose: Creates cooccurance matricies equal to the number of splits in the data
Outputs: Pandas csvs containing the cooccurance matrices
Garden of forking paths:
	Decision to filter on common terms before splitting data and training embeddings
'''

#!/usr/bin/env python3
import numpy as np
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
import string
from ast import literal_eval
from gensim.models import word2vec, KeyedVectors
from gensim.corpora import Dictionary
import mittens_utils as utils
import datetime
from collections import defaultdict
from multiprocessing import Pool  # To parallelize

num_processes = 8
window_size = 10
mincount = 0
vocab_size = 15000
directory = 'embeddings/cooc/even_split_min20/'

print("Number of processing cores: {}".format(num_processes))
print("Window size: {}".format(window_size))
print("Minimum word count: {}".format(mincount))
print("Vocab size: {}".format(vocab_size))
print("File Directory: {}".format(directory))

def trainMatrixParallel(t):
    '''
    Takes a tokenized list of documents and creates and saves a weighted cooccurance matrix
    Parameters:
        docs - a list of strings
        start_date - starting date of documents
        end_date - ending date of documents
        window_size - window size for cooccurance matrix construction
        mincount - minimum word count for cooccurance matrix to consider the word
    '''
    docs, start_date, end_date, directory, window_size, mincount = t
    
    matrix_name = start_date + '_' + end_date
    
    print("Training {} matrix".format(matrix_name))
    model_matrix = utils.build_weighted_matrix(docs, mincount=mincount, window_size=window_size, 
                                               tokenizing_func=word_tokenize)

    print("Saving {} matrix".format(matrix_name))
    model_matrix.to_csv(directory + matrix_name + '.csv', sep='|')

	
	
print("Reading in the data")
# Reads in the cleaned text
sa = pd.read_csv('sa_token.txt', sep='|')
sa = sa[(sa['speaker_id'].notnull())] # Filter out moderator
sa['statement'] = sa['statement'].apply(literal_eval)

print("Training dictionary")
# Train a dictionary on the corpus on only the vocab_size most common words
id2word = Dictionary(sa['statement'])
id2word.filter_extremes(keep_n=vocab_size)
word2id = dict((word, id) for id, word in id2word.iteritems())

print("Filtering words from statements")
# Filters statements to only include common words
sa['statement'] = sa['statement'].apply(lambda x: [word for word in x if word in word2id])

# Identifies different buckets for the calls
print("Bucketing calls")

# Converts to datetime and sorts by date of call 
sa['date'] = pd.to_datetime(sa['date'])
sa = sa[(sa['date'] >= datetime.datetime(2006, 1, 1)) & 
        (sa['date'] < datetime.datetime(2017, 1, 1))]  # Crops calls outside of observation period
sa = sa.sort_values(['date', 'url'])

# Created ordered group id
sa = sa.merge(sa.drop_duplicates('url')['url'].reset_index(drop=True).rename_axis('call_id').reset_index(), on='url')
sa.drop(columns=['url', 'firm', 'sequence_id', 'speaker', 'speaker_firm', 'gvkeyK'], inplace=True)

# Identify length of desired splits in the data
m_0 = sa.loc[(sa['date'] < datetime.datetime(2008, 7, 1)) & 
                 (sa['date'] >= datetime.datetime(2006, 1, 1)), 'statement']
token_target = sum(m_0.apply(len)) + 1  # +1 to round up

# Create a column with the word count for each statement
sa['word_count'] = sa['statement'].apply(len)

# Group by each call and bucket statements by call
calls = sa.groupby('call_id')['word_count'].sum()
calls = pd.DataFrame(calls)
calls['cumsum'] = calls['word_count'].cumsum()
calls['doc_group'] = (calls['cumsum'] / token_target).astype(int)
calls.drop(columns=['cumsum', 'word_count'], inplace=True)
sa.drop(columns=['word_count'], inplace=True)
calls.reset_index(inplace=True)

# Merges with sa to provide a bucket for each call
sa = sa.merge(calls, on='call_id')
	
print("Converting to string format for new tokenizer")
# Converts back to string format for the tokenizer
sa['statement'] = sa['statement'].apply(' '.join)


# Parallellzing
print("Parallelizing processes")

index = sa.drop_duplicates('doc_group').reset_index(drop=True)['doc_group']
max_dates = sa.groupby('doc_group')['date'].max()
min_dates = sa.groupby('doc_group')['date'].min()

# Zip data in tuples to pass to multi-processor stored in the groups array
groups = []
for i in index:
    min_date = min_dates[i].strftime('%y') + '-' + min_dates[i].strftime('%m')
    max_date = max_dates[i].strftime('%y') + '-' + max_dates[i].strftime('%m')
    docs = sa.loc[sa['doc_group'] == i, 'statement']
    groups.append((docs, min_date, max_date, directory, window_size, mincount))


if __name__ == '__main__':
    print("Training Parallelization")
    p = Pool(processes=num_processes)
    p.map(trainMatrixParallel, groups)
	


