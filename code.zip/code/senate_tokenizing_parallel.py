#!/usr/bin/env python3
'''
Author: Paul Vicinanza
Date: 12/07/2018
Purpose:
    Clean and tokenize the senate data
'''

import numpy as np
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import string
import os
from multiprocessing import Pool

os.chdir("/usr/local/ifs/gsb/amirgo/earning_calls/Senate_Language_Study")

num_processes = 24
stopwords = []  # stopwords.words('english') if stopwords are desired to be removed
punct = string.punctuation + '’–—‘“”…€'  # Additional punct added missing from string.punctuation
replace = len(punct) * ' '               # Replace with space to split tokens along punctation I'll --> [i, ll]
translator = str.maketrans(punct, replace)
sentence_tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')

# Executes the string cleaning and tokenizing process on the dataframe
def tokenize_senate(senate):
    # Remove newline characters from strings
    print("Expanding dataframe to sentence level")
    senate['speech'] = senate['speech'].apply(lambda x: x.replace('\n', ' '))

    # Expand dataframe such that each sentence its own row
    senate['speech'] = senate['speech'].astype(str).apply(sentence_tokenizer.tokenize)

    # Flatten columns of lists
    col_flat = [sentence for statement in senate['speech'] for sentence in statement] 

    # Row numbers to repeat 
    lens = senate['speech'].apply(len)
    vals = range(senate.shape[0])
    ilocations = np.repeat(vals, lens)

    # Replicate rows and add flattened column of lists
    cols = [i for i,c in enumerate(senate.columns) if c != 'speech']
    senate = senate.iloc[ilocations, cols].copy()
    senate['speech'] = col_flat

    # Convert to lowercase and removes punctuation
    print("Cleaning strings")
    senate['speech'] = senate['speech'].astype(str).apply(lambda s: s.translate(translator))
    senate['speech'] = senate['speech'].apply(str.lower)

    # Tokenize, remove stop words, and clear out empty strings
    print("Tokenizing")
    senate['speech'] = senate['speech'].apply(word_tokenize)
    senate['speech'] = senate['speech'].apply(lambda x: [word for word in x if (word not in stopwords) and 
                                                                               (not pd.isnull(word))])

    return senate

# Load the senate data
print("Reading data")
senate = pd.read_csv("speeches.csv", sep='|', encoding='utf-8')
senate['date'] = pd.to_datetime(senate['date'], format='%B %d, %Y')

# Split the dataframe into the proper number of partitions
print("Splitting dataframes")
dfs = np.array_split(senate, num_processes)

# Parallelize the function 
print("Parallelizing")
p = Pool(processes=num_processes)
senate = pd.concat(p.map(tokenize_senate, dfs))

# Export to csv as cleaned data
print("Exporting to csv")
senate.to_csv('senate_token.txt', sep='|', index=False)
