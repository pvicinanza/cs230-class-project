'''
Author: Paul Vicinanza
Date: 12/05/2018
Purpose: Clean the Q&A statements and merges to obtain date of each statement
Outputs: sa_token.txt - A '|' separated file containing each statement as a list
         amenable for embedding models
Edits:
	v2: Added functionality to split and expand dataframe for sentences within statements
'''
#!/usr/bin/env python3
import numpy as np
import pandas as pd
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import string

stopwords = []  # stopwords.words('english')
punct = string.punctuation + '’–—‘“”…€'  # Additional punct added missing from string.punctuation
replace = len(punct) * ' '               # Replace with space to split tokens along punctation I'll --> [i, ll]
translator = str.maketrans(punct, replace)
sentence_tokenizer = nltk.data.load('tokenizers/punkt/english.pickle')

def cropDate(s):
    '''
    Function to normalize the format of date time strings
    '''
    date = s.split(' ')
    if len(date) >= 3: 
        if len(date[1]) == 1:
            date[1] = '0' + date[1]
        if len(date[2]) == 2:
            date[2] = '20' + date[2]
        return date[0] + date[1] + date[2]
    else:
        return np.nan

# Reads in the main Q&A File
print("Reading in main file")
sa = pd.read_csv('all_qna_fixed.txt', header=None)
sa.columns = ['url', 'firm', 'sequence_id', 'speaker', 'speaker_firm', 'speaker_id', 'statement']
sa.head()

# Splits statements into sentences
print("Splitting sentences")
sa['statement'] = sa['statement'].astype(str).apply(sentence_tokenizer.tokenize)


# Repeat dataframe for each sentence in statement
print("Expanding Dataframe")

# Flatten columns of lists
col_flat = [sentence for statement in sa['statement'] for sentence in statement] 
# Row numbers to repeat 
lens = sa['statement'].apply(len)
vals = range(sa.shape[0])
ilocations = np.repeat(vals, lens)
# Replicate rows and add flattened column of lists
cols = [i for i,c in enumerate(sa.columns) if c != 'statement']
sa = sa.iloc[ilocations, cols].copy()
sa['statement'] = col_flat


# Reads in the gvkey and merges with sa
print("Reading in gvkey and merging with seeking alpha")
gvkey = pd.read_sas('sa_company_gvkey_link.sas7bdat')
for col in gvkey:
    gvkey[col] = gvkey[col].str.decode('utf-8')
gvkey.columns = ['firm', 'gvkey', 'gvkeyK']
gvkey.drop_duplicates(subset='firm', inplace=True)
sa = sa.merge(gvkey[['firm', 'gvkeyK']], on='firm', how='left')
sa['gvkeyK'] = sa['gvkeyK'].astype(float)   # Float necessary because no integer NaN support
sa.head()

# Converts to lowercase and removes punctuation
print("Removing punctuation")
sa['statement'] = sa['statement'].astype(str).apply(lambda s: s.translate(translator))
print("Converting to lowercase")
sa['statement'] = sa['statement'].apply(str.lower)

# Tokenizes, removes stop words
print("Tokenizing")
sa['statement'] = sa['statement'].apply(word_tokenize)

print("Removing stop words and empty strings")
sa['statement'] = sa['statement'].apply(lambda x: [word for word in x if (word not in stopwords) and 
                                                                         (not pd.isnull(word))])
print("Finished Tokenizing")

# Imports the call data to get datetime information
print("Importing calls data")
calls = pd.read_csv('all_executives.csv', header=None)
calls.drop(columns=[1, 2,3,4,6,7,8,9], inplace=True)
calls.columns=['url', 'date']
calls = calls[calls.iloc[:,1] != "TranscriptNotAvailable"]
calls.drop_duplicates('url', inplace=True)

# Converts to datetime
print("Converting to datetime")
trans = str.maketrans('', '', string.punctuation)
calls['date'] = calls['date'].astype(str).apply(lambda s: s.translate(trans))
calls['date'] = calls['date'].apply(cropDate)
calls['date'] = pd.to_datetime(calls['date'], format='%B%d%Y', errors='coerce')
calls.head()

# Merges with the statements data
print("Merging with statements data")
sa = sa.merge(calls, on='url', how='left')

# Exports to save the clean file
print("Exporting")
sa.to_csv('sa_token.txt', sep='|', index=False)
print('Finished')