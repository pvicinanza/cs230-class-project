'''
Author: Paul Vicinanza
Date: 12/05/2018
Purpose: Generate a word embedding for the entire document
'''

#!/usr/bin/env python3
import numpy as np
import pandas as pd
import gensim
import string
from ast import literal_eval
from gensim.test.utils import get_tmpfile
from gensim.models import KeyedVectors

def save_w2v(model, filename, encoding='utf-8'):
    vocab = sorted([word for word in model.wv.vocab])

    with open(filename, 'w', encoding=encoding) as outfile:
        # Write file header
        outfile.write("{} {}\n".format(len(vocab), len(model.wv[vocab[0]])))

        # Write word - vector
        for word in vocab:
            outfile.write(word + ' ' + ' '.join(str(x) for x in model.wv[word]) + '\n')

print("Reading in data")
sa = pd.read_csv('sa_token.txt', sep='|', low_memory=False)
sa = sa[sa['speaker_id'].notnull()]   # Filter out operator
sa['statement'] = sa['statement'].apply(literal_eval)

print("Training model")
model = gensim.models.Word2Vec(sa['statement'], size=200, window=10,
                               min_count=5, workers=16,
                               sg=1, negative=5, iter=5)

print("Saving model")
save_w2v(model, 'word2vec_corpus.txt')

print("Finished")