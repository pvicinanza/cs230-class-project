#!/usr/bin/env python3

'''
Author: Paul Vicinanza
Date: 11/27/2018
Purpose: Given a coocurrance matrix construct a word embedding
'''

import numpy as np
import pandas as pd
import csv  # Used for glove2dict
from mittens import GloVe, Mittens
import scipy.sparse as sp
import logging

pretrained = 'embeddings/wikipedia2014_gigaword_embeddings/glove.6B.100d.txt'
num_epoch = 150
xmax = 100
mittens = 0.1


# Load the pretrained vector
def glove2dict(glove_filename):
    '''
        Reads a glove file into a dictionary
        Taken from: https://github.com/roamanalytics/mittens
    '''
    with open(glove_filename, encoding="utf8") as f:
        reader = csv.reader(f, delimiter=' ', quoting=csv.QUOTE_NONE)
        embed = {line[0]: np.array(list(map(float, line[1:])))
                for line in reader}
    return embed
	
def train_mittens(coo_matrix, pretrained, filename=None, dim=100, max_iter=200,
                  xmax=1000, learning_rate=0.05, tol=1e-4,
                  display_progress=10,
                  mittens=0.1, encoding='utf-8'):
    '''
    Parameters:
        See https://github.com/roamanalytics/mittens/blob/master/mittens/doc.py for 
            full description of the Mittens model parameters
        coo_matrix - n x n weighted cooccurance matrix
        pretrained - pretrained embedding (from glove2dict)
        filename - Filename to save the embeddeding (if provided)
        dim - number of vector dimensions in the pretrained
        max_iter - number of iterations to run
        xmax - Word pairs with frequency greater than this are given weight 1.0.
        learning_rate - alpha for Adam Optimization
        tol - Stopping criterion for the loss
        display_progress - Frequency with which to update the progress bar
        mittens - Relative weight assigned to remaining close to the original
            embeddings. Setting to 0 means that representations are
            initialized with the original embeddings but there is no
            penalty for deviating from them. Large positive values will
            heavily penalize any deviation, so the statistics of the new
            co-occurrence matrix will be increasingly ignored. A value of
            1 is 'balanced': equal weight is given to the GloVe objective
            on the new co-occurrence matrix and to remaining close to the
            original embeddings. 0.1 (the default) is recommended.

    Returns a trained mittens model
    
    NOTE: Could obtain dim myself
    '''
    vocab = coo_matrix.index.values.tolist()
    
    # Train mittens
    mittens_model = Mittens(n=dim, max_iter=max_iter, xmax=xmax,
                            learning_rate=learning_rate, tol=tol,
                            display_progress=display_progress,
                            mittens=mittens)
    model = mittens_model.fit(
        coo_matrix,
        vocab=vocab,
        initial_embedding_dict=pretrained)
    
    # If the user provides a filename 
    if filename:
        save_mittens(model, vocab, filename, encoding=encoding)

    return model

def save_mittens(model, vocab, filename, encoding='utf-8'):
    '''
    Saves Mittens model in a format which can
        be read by gensim
    Parameters:
        Model - Trained Mittens object
        vocab - List of vocab in same order as model fit
        filename - Filename to save to
        encoding - File encoding
    '''
   
    with open(filename, 'w', encoding=encoding) as outfile:
        # Write file header
        outfile.write("{} {}\n".format(model.shape[0], model.shape[1]))
        
        # Write word - vector
        for word, index in zip(vocab, range(len(model))):
            outfile.write(word + ' ' + ' '.join(str(x) for x in model[index]) + '\n')


model_name = 'embeddings/' + input("Cooccurance matrix: ")  # Read in cooccurance matrix
model_name_wv = model_name + "_wv"

print("Number of Epochs: {}".format(num_epoch))
print("XMax: {}".format(xmax))
print("Mittens: {}".format(mittens))

print("Reading in cooccurance matrix")
model = pd.read_csv(model_name + '.csv', sep='|', index_col=0, keep_default_na=False, na_values=[''])

print("Loading pretrained vector")
pretrained_dict = glove2dict(pretrained)

print("Training model")
try:
	model_new = train_mittens(model, pretrained_dict, model_name_wv + '.txt', 
				  max_iter=num_epoch, xmax=xmax, mittens=mittens)
except:
	logging.error("Something awful happened!", exc_info=full_exc_info())
	

print("Finished")